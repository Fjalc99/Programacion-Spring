package com.salesianostriana.dam.FranciscoJoseAlcantarillaCaladoProyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FranciscoJoseAlcantarillaCaladoProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FranciscoJoseAlcantarillaCaladoProyectoApplication.class, args);
	}

}
