package com.salesianostriana.dam.FranciscoJoseAlcantarillaCaladoProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FranciscoJoseAlcantarillaCaladoProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
